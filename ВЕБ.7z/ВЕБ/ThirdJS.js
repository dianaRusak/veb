function areaRectangle(){
(function () {

    document.forma1.t1.value = 1;
    document.forma1.t2.value = 5;
    document.forma1.t3.value = 2;
    document.forma1.t4.value = 6;
    document.forma1.t5.value = 8;
    document.forma1.t6.value = 244;
    document.forma1.t7.value = 9;
    document.forma1.t8.value = 142;
    document.forma1.t9.value = 98;

    var mtrx = [];

    mtrx.push(document.forma1.t1.value);
    mtrx.push(document.forma1.t2.value);
    mtrx.push(document.forma1.t3.value);
    mtrx.push(document.forma1.t4.value);
    mtrx.push(document.forma1.t5.value);
    mtrx.push(document.forma1.t6.value);
    mtrx.push(document.forma1.t7.value);
    mtrx.push(document.forma1.t8.value);
    mtrx.push(document.forma1.t9.value);

    var summ = 0;

    for (var i = 0; i < 9; i++) 
    {
      summ += Number(mtrx[i]);  
    } 
 
    var mid = summ / 9 | 0;
    var count = 0;
 
   var table = document.createDocumentFragment();
    
    var arr = [];

    for (var i = 0; i < 3; ++i) {
        var tr = document.createElement('tr');
        arr[i] = [];
        for(var j = 0; j < 3; j++) {
            var td = document.createElement('td');
            td.innerHTML = arr[i][j] = Number(mtrx[count]) - mid;
	    count++;	
            tr.appendChild(td);
        }
        table.appendChild(tr);
     }
   document.getElementById('matrix').appendChild(table);
       
})();
} 