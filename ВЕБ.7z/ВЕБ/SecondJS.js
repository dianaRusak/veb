function areaRectangle(){ 
  var i = 1, summ = 0;
  while (i < 99)
  {
    summ += i;
    i += 2; 
  }

  var j = 101, summJ = 0;
  while (j < 199)
  {
    summJ += j;
    j += 2; 
  }

  var isTrue = confirm("Уверены, что хотите вычислить?!?!?!?!?!");

  if (isTrue == true) {
      alert(summ / summJ);
  }
} 