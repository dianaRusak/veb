function areaRectangle(){ 
var a = document.forma1.t1.value; 
var s = a * a; 
document.forma1.res.value = s; 
}

function areaClear(){
    document.forma1.t1.value = ' ';
    document.forma1.res.value = ' ';
}

